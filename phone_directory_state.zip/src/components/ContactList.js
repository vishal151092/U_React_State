import React,{useState , use} from 'react';

import './ContactList.css';
import SubscriberInfo from './SubscriberInfo';


export default function ContactList(props){

let dataList = [
    {
        id: 1,
        name: 'Jack',
        phone: '84300032223'
    },
    {
        id: 2,
        name: 'Jill',
        phone: '45959684564'
    },
    {
        id: 3,
        name: 'Shilpa',
        phone: '09748576456'
    },
    {
        id: 4,
        name: 'Narendra',
        phone: '43658537353'
    },
    {
        id: 5,
        name: 'Mota Bhai',
        phone: '766587865787'
    }
]


//let col1 = 'NAME';


const [columnOne, setColumnOne ] = useState('NAME_!');


setTimeout(()=>{
   
    setColumnOne('USER')

}, 2000);








const [contactList, setContactList ] = useState(dataList);




function clickedByUser(){
    console.log("inside ClickedByUser");
    props.onButtonClick({   name: 'Vishal'} );
}

function SubscriberContactDeleteHandler(event){
    console.log(`Deleted data: ${event}`)

     let   updatedList = contactList.filter(contact => contact.id !== event );
        setContactList([...updatedList]);


}

    return(
        <div className='container' >
            <div >
                <button className='button'>Add</button>
            </div>


            <div >
                <button onClick={clickedByUser} className='button'>Click This</button>
            </div>

            <div className='list-container'>
                <span>{columnOne}</span> 
                <span>PHONE</span>
                <span>&nbsp;</span>
                
            </div>
            <div >
              <SubscriberInfo contactData={contactList} onContactDelete={SubscriberContactDeleteHandler} />
            </div>
        </div>
    );
}
