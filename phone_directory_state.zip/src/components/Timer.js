
import React, {useState} from "react";

export default function Timers(){

   // let myTime = new Date();

/**
 *  const [clock, setClock] = useState(new Date());
    
use first parameter to show data

use second parameter(function) to update data
 */

    const [clock, setClock] = useState(new Date());

    
    setInterval(()=>{
        //myTime = new Date();
        setClock(new Date());
        console.log(clock.toLocaleTimeString());
    }, 1000);

    return(
        <h1>{clock.toLocaleTimeString()}</h1>
    )
}